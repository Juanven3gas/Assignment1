# Assignment1
# Author Juan Venegas
Assignment 1.01 for COM S 327. Program compiles as normal (gcc -Wall -Werror -g main.c -o dun_gen), and will randomly generate 6 rooms in random positions and are connected. 